#-*- coding: utf-8 -*-
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired
from flask import Flask, url_for, redirect, render_template, request


class LoginForm(FlaskForm):
    title = StringField('Заголовок')
    surname = StringField('Фамилия')
    name = StringField('Имя')
    education = StringField('Образование')
    profession = StringField('Профессия')
    sex = StringField('Пол')
    motivation = StringField('Мотивация')
    ready = StringField('Готовы остаться на Марсе?')
    submit = SubmitField('Отправить анкету')

info = None

app = Flask(__name__)

app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route('/')
@app.route('/answer', methods=['GET', "POST"])
def answer():
    if info:
        spisok1 = ["Фамилия:", "Имя:", "Образование:", "Профессия:", "Пол:", "Мотивация:", "Готовы остаться на Марсе?"]
        spisok2 = [f"{spisok1[index-1]} {info[elem]}" for index, elem in enumerate(info) if info[elem] not in ["title", "submit"] and index not in [0, 8]]
        return render_template('auto_answer.html', title=info["title"], spisok=spisok2, info=info)


@app.route('/auto_answer', methods=['GET', 'POST'])
def auto_answer():
    global info; info=None
    form = LoginForm()
    if request.method == 'POST': info = request.form; return redirect('/answer')
    elif request.method == 'GET': return render_template('auto_answer1.html', title='Анкета', form=form)

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')